Bootstrap Dropdown Menus Enhancement v3.1.1
===============================

Enhancing functionality of dropdown menus.
Added the following improvements:

* Sub-Menus
* Support for radio and checkboxes
* Positioning of menus
* Bullet for menus

For demo and docs visit [http://behigh.github.io/bootstrap_dropdowns_enhancement/](http://behigh.github.io/bootstrap_dropdowns_enhancement/)
