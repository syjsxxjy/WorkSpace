require('/quests/scripts/conditions/gather.lua')
require('/quests/scripts/conditions/ship.lua')
require('/quests/scripts/conditions/player.lua')

function conditionsMet()
  return gatherConditionsMet() and shipConditionsMet() and playerConditionsMet()
end

function questStart()
  local acceptItems = quest.configParameter("acceptItems", {})
  for _,item in ipairs(acceptItems) do
    player.giveItem(item)
  end

  local associatedMission = quest.configParameter("associatedMission")
  if associatedMission then
    player.enableMission(associatedMission)
  end
end

function questComplete()
  resolveGatherConditions()

  local enableAiCommands = quest.configParameter("enableAiCommands")
  if enableAiCommands then
    for _,command in ipairs(enableAiCommands) do
      player.enableAiCommand(command)
    end
  end

  local associatedMission = quest.configParameter("associatedMission")
  if associatedMission then
    player.completeMission(associatedMission)
  end

  local enableTech = quest.configParameter("enableTech")
  if enableTech then
    for _,tech in ipairs(enableTech) do
      player.enableTech(tech)
    end
  end

  local equipTech = quest.configParameter("equipTech")
  if equipTech then
    for _,tech in ipairs(equipTech) do
      player.enableTech(tech)
      player.equipTech(tech)
    end
  end

  local followUp = quest.configParameter("followUp")
  if followUp and player.canStartQuest(followUp) then
    local descriptor = followUp
    if type(descriptor) == "string" then
      descriptor = {
          templateId = descriptor,
          questId = descriptor,
          parameters = {}
        }
    end
    if not descriptor.parameters.questGiver then
      local p = quest.parameters()
      descriptor.parameters.questGiver = p.questReceiver or p.questGiver
    end
    player.startQuest(descriptor)
  end
end

function update(dt)
  if not player.isQuestActive(quest.questId()) then
    quest.exit()
    return
  end

  if conditionsMet() then
    if quest.configParameter("requireTurnIn", false) then
      quest.setCanTurnIn(true)
    else
      quest.complete()
    end
  end
end
