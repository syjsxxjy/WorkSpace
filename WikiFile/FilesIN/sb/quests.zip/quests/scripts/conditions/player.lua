function playerConditionsMet()
  local conditions = quest.configParameter("completionLogValues")
  if not conditions then return true end
  for logType, logValues in pairs(conditions) do
    for logKey, logValue in pairs(logValues) do
      if player.logValue(logType, logKey) < logValue then
        return false
      end
    end
  end
  return true
end
