function shipConditionsMet()
  local shipLevel = quest.configParameter("shipLevel")
  if not shipLevel then return true end
  return player.shipUpgrades().shipLevel >= shipLevel
end
