function gatherConditionsMet()
  local gatherRequirements = quest.configParameter("gatherRequirements")
  if not gatherRequirements then return true end

  if gatherRequirements.items then
    for itemName, itemReq in pairs(gatherRequirements.items) do
      if not player.hasItem({ name = itemName, count = itemReq.count }) then
        return false
      end
    end
  end

  if gatherRequirements.tags then
    local inventoryTags = player.inventoryTags()
    for itemTag, itemReq in pairs(gatherRequirements.tags) do
      if (inventoryTags[itemTag] or 0) < itemReq.count then
        return false
      end
    end
  end

  return true
end

function resolveGatherConditions()
  local gatherRequirements = quest.configParameter("gatherRequirements")
  if not gatherRequirements then return end

  if gatherRequirements.items then
    for itemName, itemReq in pairs(gatherRequirements.items) do
      if itemReq.consume then
        player.consumeItem({ name = itemName, count = itemReq.count })
      end
    end
  end

  if gatherRequirements.tags then
    for itemTag, itemReq in pairs(gatherRequirements.tags) do
      if itemReq.consume then
        player.consumeTaggedItem(itemTag, itemReq.count)
      end
    end
  end
end
