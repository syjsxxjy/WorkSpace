require("/scripts/util.lua")
require("/quests/scripts/generated/common.lua")

function onInit()
  self.questClient:setMessageHandler("enemiesDead", quest.complete)
  self.questClient:setMessageHandler("enemiesSpawned", onEnemiesSpawned)
  self.questClient:setEventHandler({"target", "death"}, onTargetDied)
end

function onTargetDied()
  -- Failed to protect target
  quest.fail()
end

function onEnemiesSpawned(_, _, npcs)
  local count = 0
  local indicators = {"target"}
  for _,npcParam in pairs(npcs) do
    local paramName = "enemy"..tostring(count)
    quest.setParameter(paramName, npcParam)
    indicators[#indicators+1] = paramName
    count = count + 1
  end
  setIndicators(indicators)
end
