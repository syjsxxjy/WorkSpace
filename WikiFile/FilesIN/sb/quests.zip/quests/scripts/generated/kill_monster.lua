require("/scripts/util.lua")
require("/quests/scripts/generated/common.lua")

function onInit()
  self.questClient:setMessageHandler("enemiesDead", onMonsterDeath)
  self.questClient:setMessageHandler("enemiesSpawned", onMonsterSpawned)
end

function onMonsterDeath()
  storage.monsterDead = true
  setIndicators({"items"})
end

function onMonsterSpawned(_, _, monsters)
  assert(#monsters == 1)
  quest.setParameter("monsterEntity", monsters[1])
  setIndicators({"monsterEntity"})
end

function conditionsMet()
  if not storage.monsterDead then
    return false
  end
  local fetchList = quest.parameters().items.items
  for _,item in ipairs(fetchList) do
    if not player.hasItem(item) then
      return false
    end
  end
  return true
end
