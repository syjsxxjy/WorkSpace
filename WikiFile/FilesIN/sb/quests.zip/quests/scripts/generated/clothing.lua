require("/quests/scripts/generated/common.lua")
require("/quests/scripts/generated/text_generation.lua")

function onInit()
  self.questClient:setEventHandler({"friend", "interaction"}, onFriendInteraction)
  self.questClient:setEventHandler({"friend", quest.configParameter("clothingCraftedEventName")}, onClothingCrafted)
  self.questClient:setEventHandler({"questGiver", "interaction"}, onQuestGiverInteraction)
  self.questClient:setEventHandler({"questGiver", quest.configParameter("clothingAcceptedEventName")}, onClothingAccepted)
end

function onFriendInteraction(target, interactor)
  if interactor ~= entity.id() then return end
  if not hasClothingIngredients() then return end
  if storage.receivedParcel then return end

  notifyNpc("friend", quest.configParameter("requestClothingCraftNotification"))
end

function onClothingCrafted(target, interactor)
  if interactor ~= entity.id() then return end
  
  setIndicators({"questGiver"})
  storage.receivedParcel = true
  consumeClothingIngredients()

  local parcelDescriptionConfig = quest.configParameter("parcelDescription")
  local parcelNameConfig = quest.configParameter("parcelName")
  local description = generateText(parcelDescriptionConfig)
  local shortdescription = generateText(parcelNameConfig)
  player.giveItem({
      name = "parcel",
      count = 1,
      parameters = {
          questTag = quest.questId(),
          description = description,
          shortdescription = shortdescription
        }
    })
end

function onQuestGiverInteraction(target, interactor)
  if interactor ~= entity.id() then return end
  if not hasClothingParcel() then return end

  notifyNpc("questGiver", quest.configParameter("wearClothingNotification"))
end

function onClothingAccepted(target, interactor)
  if interactor ~= entity.id() then return end
  player.consumeItemWithParameter("questTag", quest.questId(), 1)
  quest.complete()
end

function hasClothingIngredients()
  local ingredients = quest.parameters().clothingIngredients.items
  for _,ingredient in pairs(ingredients) do
    if not player.hasItem(ingredient) then
      return false
    end
  end
  return true
end

function consumeClothingIngredients()
  local ingredients = quest.parameters().clothingIngredients.items
  for _,ingredient in pairs(ingredients) do
    player.consumeItem(ingredient)
  end
end

function hasClothingParcel()
  return player.hasItemWithParameter("questTag", quest.questId())
end

function onQuestStart()
  setIndicators({"friend", "clothingIngredients"})
end
