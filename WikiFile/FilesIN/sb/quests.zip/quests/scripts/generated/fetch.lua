require("/quests/scripts/generated/common.lua")

function onQuestStart()
  local giveItems = quest.configParameter("giveItems")
  if giveItems then
    local items = quest.parameters()[giveItems].items
    for _,item in ipairs(items) do
      player.giveItem(item)
    end
  end

  -- If this is a crafting / cooking quest, give the player the necessary
  -- blueprints.
  if quest.parameters().recipes then
    for _,item in ipairs(quest.parameters().recipes.items) do
      player.giveBlueprint(item)
    end
  end

  local fetchList = quest.configParameter("fetchList")
  if fetchList then
    setIndicators({fetchList})
  else
    setIndicators({})
  end
end

function conditionsMet()
  local paramName = quest.configParameter("fetchList")
  if not paramName then return true end
  local fetchList = quest.parameters()[paramName].items
  for _,item in ipairs(fetchList) do
    if not player.hasItem(item) then
      return false
    end
  end
  return true
end
