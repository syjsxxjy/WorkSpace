require("/quests/scripts/generated/common.lua")
require("/quests/scripts/generated/text_generation.lua")

function onInit()
  self.questClient:setEventHandler({"target", "interaction"}, onTargetInteraction)
  self.questClient:setEventHandler({"target", quest.configParameter("tradeAcceptedEventName")}, onTradeAccepted)
  self.questClient:setEventHandler({"questGiver", "interaction"}, onQuestGiverInteraction)
  self.questClient:setEventHandler({"questGiver", quest.configParameter("stockAcceptedEventName")}, onStockAccepted)
end

function onTargetInteraction(target, interactor)
  if interactor ~= entity.id() then return end
  if not hasTradedItems() then return end
  if storage.receivedParcel then return end

  notifyNpc("target", quest.configParameter("requestTradeNotification"))
end

function onTradeAccepted(target, interactor)
  if interactor ~= entity.id() then return end
  
  setIndicators({"questGiver"})
  storage.receivedParcel = true
  consumeTradedItems()

  local parcelDescriptionConfig = quest.configParameter("parcelDescription")
  local parcelNameConfig = quest.configParameter("parcelName")
  local description = generateText(parcelDescriptionConfig)
  local shortdescription = generateText(parcelNameConfig)
  player.giveItem({
      name = "parcel",
      count = 1,
      parameters = {
          questTag = quest.questId(),
          description = description,
          shortdescription = shortdescription
        }
    })
end

function onQuestGiverInteraction(target, interactor)
  if interactor ~= entity.id() then return end
  if not hasParcel() then return end

  notifyNpc("questGiver", quest.configParameter("stockDeliveredNotification"))
end

function onStockAccepted(target, interactor)
  if interactor ~= entity.id() then return end
  player.consumeItemWithParameter("questTag", quest.questId(), 1)
  quest.complete()
end

function hasTradedItems()
  local items = quest.parameters().tradedItems.items
  for _,item in pairs(items) do
    if not player.hasItem(item) then
      return false
    end
  end
  return true
end

function consumeTradedItems()
  local items = quest.parameters().tradedItems.items
  for _,item in pairs(items) do
    player.consumeItem(item)
  end
end

function hasParcel()
  return player.hasItemWithParameter("questTag", quest.questId())
end

function onQuestStart()
  setIndicators({"target", "tradedItems"})
end
