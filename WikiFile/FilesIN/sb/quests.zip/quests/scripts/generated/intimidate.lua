require("/scripts/util.lua")
require("/quests/scripts/generated/common.lua")

function onInit()
  self.questClient:setEventHandler({"target", "interaction"}, onTargetInteraction)
  self.questClient:setEventHandler({"target", "intimidated"}, onIntimidated)
end

function onTargetInteraction(target, interactor)
  if interactor ~= entity.id() then return end
  if storage.intimidated then return end

  if holdingRequiredItem() then
    notifyNpc(target, "intimidate")
  else
    notifyNpc(target, "failToIntimidate")
  end
end

function onIntimidated(target, interactor)
  if interactor ~= entity.id() then return end
  storage.intimidated = true
  setIndicators({})
end

function holdingRequiredItem()
  local requiredTag = quest.parameters().item.tag
  local primaryTags = player.primaryHandItemTags()
  local altTags = player.altHandItemTags()
  return contains(primaryTags, requiredTag) or contains(altTags, requiredTag)
end

function conditionsMet()
  return storage.intimidated
end
