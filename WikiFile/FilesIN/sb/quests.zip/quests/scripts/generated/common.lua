require("/scripts/quest/player.lua")

-- This script provides the boilerplate needed to script a genrated quest.
-- You can provide any/all of these methods if you need custom functionality
-- during callbacks:
--   onInit, onUninit, onQuestStart, onQuestComplete, onQuestFail, onUpdate,
--   and conditionsMet (which returns a bool).
-- You can define these values in the scriptConfig:
--   portraitParameter, requireTurnIn, indicators.

function init()
  self.outbox = Outbox.new("questOutbox", PlayerContactList.new("questContacts"))
  self.questClient = QuestPlayer.new("quest", self.outbox)

  storage.indicators = storage.indicators or quest.configParameter("indicators", {})

  self.questClient:setEventHandler("updatePortrait", onUpdatePortrait)

  if onInit then onInit() end
end

function onUpdatePortrait(uniqueId, portrait)
  for paramName, paramValue in pairs(quest.parameters()) do
    if paramValue.uniqueId == uniqueId then
      paramValue.portrait = portrait
      quest.setParameter(paramName, paramValue)
    end
  end
end

function setIndicators(indicators)
  storage.indicators = indicators
end

function uninit()
  if onUninit then onUninit() end
  self.questClient:uninit()
end

function questComplete()
  self.questClient:questComplete()

  if onQuestComplete then onQuestComplete() end
end

function questFail()
  self.questClient:questFail()

  if onQuestFail then onQuestFail() end
end

function questStart()
  self.questClient:questStart()

  if onQuestStart then onQuestStart() end
end

function update(dt)
  self.questClient:update()
  if not player.isQuestActive(quest.questId()) then
    -- Keep trying to send postponed messages after the quest is completed/failed
    if self.outbox:empty() then
      quest.exit()
    end
    return
  end

  if quest.configParameter("requireTurnIn") then
    if not conditionsMet then
      quest.setCanTurnIn(true)
      quest.setIndicators(storage.indicators)
    elseif conditionsMet() then
      quest.setCanTurnIn(true)
      quest.setIndicators({})
    else
      quest.setCanTurnIn(false)
      quest.setIndicators(storage.indicators)
    end
  elseif conditionsMet and conditionsMet() then
    quest.complete()
  else
    quest.setIndicators(storage.indicators)
  end

  if onUpdate then onUpdate(dt) end
end

function notifyNpc(name, notificationType)
  if quest.parameters()[name] and quest.parameters()[name].uniqueId then
    name = quest.parameters()[name].uniqueId
  end
  self.outbox:sendMessage(name, "notify", {
      type = notificationType,
      sourceId = entity.id()
    })
end
