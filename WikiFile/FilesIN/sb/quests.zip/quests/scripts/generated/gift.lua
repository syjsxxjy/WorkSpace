require("/quests/scripts/generated/common.lua")

function onInit()
  self.questClient:setEventHandler({"target", "interaction"}, onTargetInteraction)
  self.questClient:setEventHandler({"target", quest.configParameter("giftAcceptedEventName")}, onGiftAccepted)
  self.questClient:setEventHandler({"target", quest.configParameter("requestAdditionToHouseEventName")}, onRequestAdditionToHouse)
end

function onTargetInteraction(target, interactor)
  if interactor ~= entity.id() then return end

  if hasGift() and not storage.giftAccepted then
    notifyNpc(target, quest.configParameter("provideGiftNotification"))
  end
end

function onGiftAccepted(target, interactor)
  if interactor ~= entity.id() then return end
  if not hasGift() then return end

  local gift = quest.parameters().gift.item
  player.consumeItem(gift)

  storage.giftAccepted = true
end

function onRequestAdditionToHouse(target, interactor)
  if interactor ~= entity.id() then return end
  if not hasGift() then return end

  self.questClient:setEventHandler({"recipientDeed", "objectAdded"}, onObjectAdded)
  storage.addingToHouse = true
end

function onObjectAdded(deedUniqueId, objectName)
  if storage.addingToHouse and objectName == quest.parameters().gift.item.name then
    storage.giftAccepted = true
    notifyNpc("target", quest.configParameter("objectAddedNotification"))
  end
end

function hasGift()
  if storage.giftAccepted then return false end

  local gift = quest.parameters().gift.item
  return player.hasItem(gift)
end

function conditionsMet()
  return storage.giftAccepted
end

function onUpdate()
  if conditionsMet() then
    setIndicators({})
    return
  else
    local indicators = {"target"}
    if storage.addingToHouse then
      indicators[#indicators+1] = "recipientDeed"
    end
    if not hasGift() then
      indicators[#indicators+1] = "gift"
    end
    setIndicators(indicators)
  end
end
