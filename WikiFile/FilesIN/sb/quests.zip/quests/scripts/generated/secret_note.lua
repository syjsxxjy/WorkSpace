require("/quests/scripts/generated/common.lua")
require("/quests/scripts/generated/text_generation.lua")

function onInit()
  self.questClient:setEventHandler({"target", "interaction"}, onTargetInteraction)
  self.questClient:setEventHandler({"target", "secretShared"}, onSecretShared)
end

function onTargetInteraction(target, interactor)
  if interactor ~= entity.id() then return end
  if not playerHasNote("message") then return end

  notifyNpc(target, "shareSecret")
end

function onSecretShared(target, interactor)
  if interactor ~= entity.id() then return end
  if not playerHasNote("message") then return end

  player.consumeItemWithParameter("questTag", noteTag("message"), 1)
  player.giveItem(generateNoteItem("response", quest.configParameter("responseNote")))
  setIndicators({})
end

function onQuestStart()
  player.giveItem(generateNoteItem("message", quest.configParameter("secretNote")))
end

function onQuestComplete()
  player.consumeItemWithParameter("questTag", noteTag("response"), 1)
end

function playerHasNote(tagSuffix)
  return player.hasItemWithParameter("questTag", noteTag(tagSuffix))
end

function conditionsMet()
  return playerHasNote("response")
end
