require("/quests/scripts/generated/common.lua")

function onInit()
  self.questClient:setEventHandler({"thiefDeed", "objectRemoved"}, onObjectRemoved)
end

function onObjectRemoved(deedUniqueId, objectName)
  if storage.objectRemoved then return end
  if quest.parameters().item.item.name == objectName then
    storage.objectRemoved = true
    self.questClient:setEventHandler({"victimDeed", "objectAdded"}, onObjectAdded)
    setIndicators({"victimDeed"})
    notifyNpc("thief", "objectTaken")
  end
end

function onObjectAdded(deedUniqueId, objectName)
  if quest.parameters().item.item.name == objectName then
    quest.complete()
  end
end
