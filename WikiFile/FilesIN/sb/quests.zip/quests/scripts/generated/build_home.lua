require("/quests/scripts/generated/common.lua")

function onInit()
  message.setHandler("colonyDeed.newHome", onNewHome)
end

function onNewHome(_, _, tenants, furniture, boundary)
  local furnitureNeeded = quest.parameters().furnitureSet.items
  for _,itemDescriptor in ipairs(furnitureNeeded) do
    if (furniture[itemDescriptor.name] or 0) < itemDescriptor.count then
      return
    end
  end

  quest.complete()
end
