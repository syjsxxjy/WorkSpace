require("/scripts/util.lua")

function generateText(config)
  local tags = {}
  for paramName, paramValue in pairs(quest.parameters()) do
    if paramValue.name then
      tags[paramName] = paramValue.name
    elseif paramValue.type == "item" then
      local itemConfig = root.itemConfig(paramValue.item.name)
      tags[paramName] = itemConfig.config.shortdescription
    end
  end

  for tag, words in pairs(config.words or {}) do
    tags[tag] = words[math.random(#words)]
  end

  local template = config.templates[math.random(#config.templates)]
  return sb.replaceTags(template, tags)
end

function noteTag(tagSuffix)
  return quest.questId().."-"..tagSuffix
end

function generateNoteItem(tagSuffix, noteConfig, title)
  return {
      name = "secretnote",
      count = 1,
      parameters = {
        shortdescription = title,
        questTag = noteTag(tagSuffix),
        description = "\""..generateText(noteConfig).."\""
      }
    }
end
