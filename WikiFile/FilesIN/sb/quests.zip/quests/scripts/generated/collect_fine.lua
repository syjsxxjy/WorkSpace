require("/quests/scripts/generated/common.lua")
require("/quests/scripts/generated/text_generation.lua")

function onInit()
  self.questClient:setEventHandler({"target", "interaction"}, onTargetInteraction)
end

function onQuestStart()
  player.giveItem(generateNoteItem("crime", quest.configParameter("crimeNotice"), "Crime Notice"))
end

function onTargetInteraction(targetUniqueId, interactorEntityId)
  if interactorEntityId == entity.id() and not storage.interacted and hasNotice() then
    notifyNpc(targetUniqueId, "collectFine")
    self.questClient:setEventHandler({"target", "fineCollected"}, onFineCollected)
  end
end

function onFineCollected(targetUniqueId, interactorEntityId)
  if interactorEntityId == entity.id() and hasNotice() then
    storage.interacted = true
    player.consumeItemWithParameter("questTag", noteTag("crime"), 1)
    player.giveItem(quest.parameters().item.item)
  end
end

function hasItem()
  return player.hasItem(quest.parameters().item.item)
end

function hasNotice()
  return player.hasItemWithParameter("questTag", noteTag("crime"))
end

function conditionsMet()
  return storage.interacted and hasItem()
end
