require("/quests/scripts/generated/common.lua")

function onInit()
  self.questClient:setEventHandler({"target", "interaction"}, onTargetInteraction)
  self.questClient:setEventHandler({"target", quest.configParameter("giftReceivedEventName")}, onGiftReceived)
end

function onTargetInteraction(target, interactor)
  if interactor ~= entity.id() then return end

  if not storage.giftReceived then
    notifyNpc(target, quest.configParameter("requestGiftNotification"))
  end
end

function onGiftReceived(target, interactor)
  if interactor ~= entity.id() then return end
  if storage.giftReceived then return end

  local gift = quest.parameters().item.item
  player.giveItem(gift)
  storage.giftReceived = true
  setIndicators({})
end

function hasItem()
  if not storage.giftReceived then return false end

  local gift = quest.parameters().item.item
  return player.hasItem(gift)
end

function conditionsMet()
  return storage.giftReceived and hasItem()
end
