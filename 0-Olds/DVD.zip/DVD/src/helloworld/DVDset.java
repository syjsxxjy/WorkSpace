package helloworld;

public class DVDset {
	public static String name[] = new String[50];
	public static String state[] = new String[50];
	public static String date[] = new String[50];

		public String[] getName() {
		return name;
	}

	public void setName(String string) {
		
	}

	public String[] getState() {
		return state;
	}

	public void setState(String[] state) {
		this.state = state;
	}

	public String[] getDate() {
		return date;
	}

	public void setDate(String[] date) {
		this.date = date;
	}

		public DVDset() {
		// TODO Auto-generated constructor stub
	}

		public static Object name(int i) {
			// TODO Auto-generated method stub
			return null;
			
		}

}
