package controller;

import java.util.Scanner;

import model.UserInfo;
import dao.UserDao;

public class BaseController {
	
	static Scanner input = new Scanner(System.in);
	
}
