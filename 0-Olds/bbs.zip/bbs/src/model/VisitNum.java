package model;

public class VisitNum {
       private  long visitnum;

	public long getVisitnum() {
		return visitnum;
	}

	public void setVisitnum(long visitnum) {
		this.visitnum = visitnum;
	}
}
